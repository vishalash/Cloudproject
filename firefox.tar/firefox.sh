ssh -X -l root 192.168.43.80 firefox
